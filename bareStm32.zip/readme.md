# Embedded ARM — PowerOn to main()

THis is a simple embedded program using Linker Script, Assembly and C to initialize the microcontroller and hand over to C programs to work with multiple threads and interact with peripherals. 

A much detailed **Udemy course** https://www.udemy.com/course/coding-baremetal-scheduler-a-rtos-functionality/ covers until blinking LEDs, creating terminal user interface using UART and a scheduling algorithm for running multiple tasks. 

The details upto execution of main() C function is in blog https://medium.com/@malaydasat/embedded-arm-poweron-to-main-d81fca36ca7f

The same is described on **youtube playlist** https://www.youtube.com/playlist?list=PLQQmMGmejomcjZTyE0gAuOF-6rIfAqXCS
